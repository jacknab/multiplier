
<?php $__env->startSection('content'); ?>
    <div class="active" id="via-email">
        <form class="register-form row w-25" style="margin: 100px auto 0 auto; color: white !important;">
            <h2>Refferal</h2>
            <?php echo csrf_field(); ?>
            <div class="col-md-12 col-12">
                <p>My Code: <?php echo e(user('id')); ?></p>
            </div>
            <div class="col-md-12 col-12">
                <p>My URL: <a href="<?php echo e(url('register?refer'.user('id'))); ?>"><?php echo e(url('register?refer'.user('id'))); ?></a></p>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout.usergame2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/luckysho/test.luckyshots.in/laravel/resources/views/refferal.blade.php ENDPATH**/ ?>