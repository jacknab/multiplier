<!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title><?php echo e(env('APP_NAME')); ?></title>
<!-- plugins:css -->
<link rel="stylesheet" href="/aviatoradmin/assets/vendors/mdi/css/materialdesignicons.min.css">
<link rel="stylesheet" href="/aviatoradmin/assets/vendors/css/vendor.bundle.base.css">
<!-- endinject -->
<!-- Plugin css for this page -->
<link rel="stylesheet" href="<?php echo e(asset('vendor/izitoast/css/iziToast.min.css')); ?>">
<!-- End plugin css for this page -->
<!-- inject:css -->
<!-- endinject -->
<!-- Layout styles -->
<link rel="stylesheet" href="/aviatoradmin/assets/css/style.css">
<link rel="stylesheet" href="<?php echo e(asset('aviatoradmin/izitoast/css/iziToast.min.css')); ?>">
<!-- End layout styles -->
<link rel="shortcut icon" href="/images/logo.png" /><?php /**PATH /home/u558340823/domains/thixpro.in/public_html/aviator/laravel/resources/views/include/admin/head.blade.php ENDPATH**/ ?>